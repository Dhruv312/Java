public class Task41{
	public static void main(String[] args){
		char str='Z';
		int a=str;
		System.out.println("The ASCII value of "+str+" is: "+a);
	}
}