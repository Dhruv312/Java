import java.util.Scanner;

public class Task23{
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		System.out.println("Input the Binary num: ");
		int num=sc.nextInt();
		
		int count=0;
		int rem,sum=0;
		int d;
		
		while(num!=0){
			rem=num%10;
			d=rem;
			count++;
			
			for(int i=1;i<count;i++){
				d=d*2;
			}
			
			num=num/10;
			sum=sum+d;
		}
		
		if(sum<16){
			if(sum==10){
				System.out.println("Hexadecimal: A");
			}else if(sum == 11){
				System.out.println("Hexadecimal: B");
			}else if(sum == 12){
				System.out.println("Hexadecimal: c");
			}else if(sum == 13){
				System.out.println("Hexadecimal: D");
			}else if(sum == 14){
				System.out.println("Hexadecimal: E");
			}else if(sum == 15){
				System.out.println("Hexadecimal: F");
			}else{
				System.out.println("Hexadecimal:"+sum);
			}
		}
	}
}
