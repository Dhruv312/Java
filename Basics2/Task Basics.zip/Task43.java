public class Task43{
	public static void main(String[] args){
		System.out.println("Twinkle, twinkle, little star,");
		System.out.println("\tHow I wonder what you are! ");
		System.out.println("\t\tUp above the world so high,");
		System.out.println("\t\tLike a diamond in the sky.");
		System.out.println("Twinkle, twinkle, little star,");
		System.out.println("\tHow I wonder what you are");
	}
}
