//2. Write a Java program to print the sum of two numbers.
//Test Data:
//74 + 36
//Expected Output :
//110
import java.util.Scanner;
public class Task2{
	public static void main(String[] args){
			Scanner sc=new Scanner(System.in);
			int num1=sc.nextInt();
			int num2=sc.nextInt();
			System.out.println("The sum of two  num: "+(num1+num2));
	}
}