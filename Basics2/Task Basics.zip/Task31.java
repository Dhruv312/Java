public class Task31{
	public static void main(String[] args){
		
	}
}