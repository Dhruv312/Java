import java.util.Scanner;

public class Task22{
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		System.out.println("Input the Binary num: ");
		int num=sc.nextInt();
		int count=0;
		int rem,sum=0;
		int d;
		while(num!=0){
			rem=num%10;
			d=rem;
			count++;
			for(int i=1;i<count;i++){
				d=d*2;
			}
			
			num=num/10;
			sum=sum+d;
		}
		
		System.out.println("sum: "+sum);
	}
}