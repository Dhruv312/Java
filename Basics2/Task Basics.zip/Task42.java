import java.util.Scanner;
public class Task42{
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		System.out.println("Input password: ");
		String password=sc.nextLine();
		
		System.out.println("Your password is: "+password);
	}
}