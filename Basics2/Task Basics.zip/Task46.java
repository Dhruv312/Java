import java.util.Date;
public class Task46{
	public static void main(String[] args){
		Date currentdatte= new Date();
		System.out.println("Current Date Time: "+currentdatte);
	}
}